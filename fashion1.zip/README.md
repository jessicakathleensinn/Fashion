# Jessie's Fashion Sketch (MVP)

This is a single-page web app that lets you place fabric photos over a base body image, mask areas (bodice/skirt/sleeve), and export a PNG.

## Run locally
- Open `index.html` in your browser.

## Deploy to GitHub Pages
1. Create a new GitHub repo (public).
2. Upload the contents of this folder (keep the `assets/` folder next to `index.html`).
3. In the repo, go to **Settings → Pages → Source** and select **Deploy from a branch**.
4. Pick the `main` branch and `/ (root)` folder. Save.  
5. After it builds, your site will be live at the Pages URL.

## Deploy to Netlify
1. Go to https://app.netlify.com → **Add new site** → **Import an existing project**.
2. Connect your GitHub repo (or drag the folder to **Deploys**).
3. Build command: _none_ (static site), Publish directory: `/` (root).
4. Click **Deploy**. Your site gets a `*.netlify.app` URL.

- `netlify.toml` is included (not strictly required but nice to have).
